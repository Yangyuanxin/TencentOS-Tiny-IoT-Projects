#ifndef TOS_CONFIG_H
#define  TOS_CONFIG_H

#include "stm32f4xx.h"

#define TOS_CFG_TASK_PRIO_MAX           10u

#define TOS_CFG_ROUND_ROBIN_EN          1u

#define TOS_CFG_OBJECT_VERIFY_EN           1u

#define TOS_CFG_TASK_DYNAMIC_CREATE_EN  0u

#define TOS_CFG_EVENT_EN                1u

#define TOS_CFG_MMBLK_EN                1u

#define TOS_CFG_MMHEAP_EN               1u

#define TOS_CFG_MMHEAP_DEFAULT_POOL_SIZE        0x100

#define TOS_CFG_MUTEX_EN                1u

#define TOS_CFG_TIMER_EN                1u

//#define TOS_CFG_PWR_MGR_EN              0u   //STM32F407

#define TOS_CFG_TICKLESS_EN             0u

#define TOS_CFG_SEM_EN                  1u

//#define TOS_CFG_FAULT_BACKTRACE_EN      0u   //STM32F407

/*
STM32F401 128u
STM32F407 512u
*/
#define TOS_CFG_IDLE_TASK_STK_SIZE      128u

#define TOS_CFG_CPU_TICK_PER_SECOND     1000u

#define TOS_CFG_CPU_CLOCK     (SystemCoreClock)

#define TOS_CFG_TIMER_AS_PROC           1u

#endif
